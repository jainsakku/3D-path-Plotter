The Following streps are followed when a use r install the app;
1. The user signin using a unique username and password which also have ceryain constraints.
2. After successful login following information of the user is send to the online database
	1.