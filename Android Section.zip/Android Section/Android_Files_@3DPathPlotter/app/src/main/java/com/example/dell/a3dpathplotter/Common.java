package com.example.dell.a3dpathplotter;

import java.text.DateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * Created by Dell on 15-09-2017.
 */

public class Common {
    public static String serverip;

    public static String getUrl() {
        return "http://plot3d.heliohost.org/QueryProcessor_3Dpath.php";
    }


    public static String getYyyymmdd(java.util.Date dt)
    {
        String str="";
        java.util.Calendar cal=java.util.Calendar.getInstance();
        cal.setTimeInMillis(dt.getTime());
        str=cal.get(Calendar.YEAR)+"-"+(cal.get(Calendar.MONTH)+1)+"-"+cal.get(Calendar.DATE);
        return str;
    }



}
